﻿using Microsoft.AspNetCore.Mvc;

namespace SistemaFinanceiroUGB20232.Controllers
{
    public class TesteController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
